.class Landroid/support/v4/app/NotificationManagerCompatIceCreamSandwich;
.super Ljava/lang/Object;
.source "NotificationManagerCompatIceCreamSandwich.java"


# static fields
.field static final SIDE_CHANNEL_BIND_FLAGS:I = 0x21


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
